package com.turing.challenge.backend.order.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface IUserOrderDao {
	
	static final String INSERT_USER_ORDER = "insert into user_orders (order_id, user_id, order_status, order_amount, created_at) values (?, ?, ?, ?, now());";
	
	static final String INSERT_USER_ORDER_PRODUCT = "insert into user_order_products (order_id, product_id, product_price, quantity, created_at) "
				  						  		   + "values (?, ?, ?, ?, now());";

	static final String UPDATE_USER_ORDER_STATUS = "update user_orders set order_status = ?, updated_at = now() where order_id = ?";

	static final String SELECT_USER_ORDERS = "select uo.sr_no, uo.order_id, uo.user_id, uo.order_status, uo.order_amount, uop.product_id, uop.product_price, uop.quantity "
										   + "from user_orders uo, user_order_products uop where uo.order_id = uop.order_id and uo.user_id = ?";

	static final String SELECT_USER_ORDERS_BY_STATUS = "select uo.sr_no, uo.order_id, uo.user_id, uo.order_status, uo.order_amount, uop.product_id, uop.product_price, uop.quantity "
			   										 + "from user_orders uo, user_order_products uop where uo.order_id = uop.order_id and uo.user_id = ? and uo.order_status = ?";

	static final String SELECT_ORDERS_BY_STATUS = "select uo.sr_no, uo.order_id, uo.user_id, uo.order_status, uo.order_amount, uop.product_id, uop.product_price, uop.quantity "
						 						+ "from user_orders uo, user_order_products uop where uo.order_id = uop.order_id and uo.order_status = ?";
	
	static final String SELECT_NEXT_N_ORDERS = "select uo.sr_no, uo.order_id, uo.user_id, uo.order_status, uo.order_amount, uop.product_id, uop.product_price, uop.quantity "
											 + "from (select * from user_orders where sr_no > ? and user_id = ? order by sr_no limit ?) uo, user_order_products uop "
											 + "where uo.order_id = uop.order_id order by uo.sr_no";
	
	static final String SELECT_PREV_N_ORDERS = "select uo.sr_no, uo.order_id, uo.user_id, uo.order_status, uo.order_amount, uop.product_id, uop.product_price, uop.quantity "
											 + "from (select * from user_orders where sr_no < ? and user_id = ? order by sr_no desc limit ?) uo, user_order_products uop "
											 + "where uo.order_id = uop.order_id order by uo.sr_no";

	int insertUserOrder(UserOrder userOrder, Connection connection);
	int insertUserOrderProduct(UserOrderProduct userOrderProduct, Connection connection);
	int updateUserOrderStatus(long orderId, String orderStatus, Connection connection);
	List<UserOrder> selectUserOrders(String userId, Connection connection) throws SQLException;
	List<UserOrder> selectUserOrdersByStatus(String userId, String orderStatus, Connection connection) throws SQLException;
	List<UserOrder> selectOrdersByStatus(String orderStatus, Connection connection) throws SQLException;
	List<UserOrder> selectNextNOrders(int lastMaxSrNo, String userId, int pageSize, Connection connection) throws SQLException;
	List<UserOrder> selectPrevNOrders(int lastMinSrNo, String userId, int pageSize, Connection connection) throws SQLException;
	
}
