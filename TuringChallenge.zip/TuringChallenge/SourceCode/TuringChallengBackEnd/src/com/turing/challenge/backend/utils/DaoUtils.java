package com.turing.challenge.backend.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.turing.challenge.backend.cache.PropertiesManager;

public class DaoUtils {
	
	private static final Logger LOGGER = LogManager.getLogger(DaoUtils.class);
	
	private static final PropertiesManager propertiesManager = PropertiesManager.getInstance();
	
	private static final String driver = "com.mysql.jdbc.Driver";
	private static final String url = "jdbc:mysql://localhost:3306/turing01";
	private static final String userId = "turing01";
	private static final String password = "turing01";
	
	public static Connection createConnection(){
		Connection connection = null;
		try {
			Class.forName(propertiesManager.getStringValue("driver", driver));
			connection = DriverManager.getConnection(propertiesManager.getStringValue("url", url), propertiesManager.getStringValue("userId", userId), propertiesManager.getStringValue("password", password));
		} catch (Exception e) {
			LOGGER.error("Exception occurred while creating connection.", e);
		}
		return connection;
	}
	
	public static Connection createConnection(String driver, String url, String userId, String password){
		Connection connection = null;
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, userId, password);
		} catch (Exception e) {
			LOGGER.error("Exception occurred while creating connection.", e);
		}
		return connection;
	}
	
	public static void closeResultSet(ResultSet rs) {
		try {
			if(null != rs) {
				rs.close();
			}
		}catch(Exception e) {
			LOGGER.error("Exception occurred in closeResultSet()", e);
		}
	}
	
	public static void closePreparedStatement(PreparedStatement ps) {
		try {
			if(null != ps) {
				ps.close();
			}
		}catch(Exception e) {
			LOGGER.error("Exception occurred in closePreparedStatement()", e);
		}
	}
	
	public static void closeConnection(Connection con) {
		try {
			if(null != con) {
				con.close();
			}
		}catch(Exception e) {
			LOGGER.error("Exception occurred in closeConnection()", e);
		}
	}
	
	public static void setAutoCommit(Connection con, boolean autoCommit) {
		try {
			if(null != con) {
				con.setAutoCommit(autoCommit);
			}
		}catch(Exception e) {
			LOGGER.error("Exception occurred in closeConnection()", e);
		}
	}
	
	public static void commit(Connection con) {
		try {
			if(null != con) {
				con.commit();
			}
		}catch(Exception e) {
			LOGGER.error("Exception occurred in closeConnection()", e);
		}
	}
	
	public static void rollBack(Connection con) {
		try {
			if(null != con) {
				con.rollback();
			}
		}catch(Exception e) {
			LOGGER.error("Exception occurred in closeConnection()", e);
		}
	}

}
