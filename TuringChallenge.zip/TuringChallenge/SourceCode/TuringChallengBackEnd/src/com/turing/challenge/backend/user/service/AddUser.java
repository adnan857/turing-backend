package com.turing.challenge.backend.user.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.regex.Pattern;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.turing.challenge.backend.service.AService;
import com.turing.challenge.backend.user.dao.User;
import com.turing.challenge.backend.user.dao.UserDaoImpl;
import com.turing.challenge.backend.utils.DaoUtils;
import com.turing.challenge.backend.utils.MappingUtils;

public class AddUser extends AService{
	
	private static final Logger LOGGER = LogManager.getLogger(AddUser.class);

	@Override
	public String process(String request) throws JsonParseException, JsonMappingException, IOException {
		
		User user = MappingUtils.OBJECT_MAPPER.readValue(request, User.class);
		
		Connection con = DaoUtils.createConnection();
		
		try {
			if(user.getUserId().length() < 6 || user.getPassword().length() < 6 || !Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE).matcher(user.getEmail()).find()) {
				DaoUtils.closeConnection(con);
				return "USR_01";
			}
			User _user = UserDaoImpl.getInstance().selectUser(user.getUserId(), con);
			if(null != _user) {
				DaoUtils.closeConnection(con);
				return "USR_04";
			}
		}catch(SQLException e) {
			LOGGER.error("Exception occurred in process()", e);
			DaoUtils.closeConnection(con);
			return "failure";
		}
		
		int rowsInserted = UserDaoImpl.getInstance().insertUser(user, con);
		
		DaoUtils.closeConnection(con);
		
		return rowsInserted > 0 ? "success" : "failure";
	}

}
