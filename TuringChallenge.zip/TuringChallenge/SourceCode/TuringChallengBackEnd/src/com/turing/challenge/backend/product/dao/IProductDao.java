package com.turing.challenge.backend.product.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface IProductDao {
	
	static final String INSERT_PRODUCT = "insert into products (product_id, type_id, product_name, product_desc, product_price, created_at) "
									   + "values (?, ?, ?, ?, ?, now());";
	
	static final String UPDATE_PRODUCT = "update products set type_id = ?, product_name = ?, product_desc = ?, "
									   + "product_price = ?, updated_at = now() where product_id = ?";
	
	static final String SELECT_ALL_PRODUCTS = "select p.sr_no, p.product_id, p.type_id, p.product_name, p.product_desc, p.product_price "
											+ "from products p";
	
	static final String SELECT_PRODUCT_BY_ID = "select p.sr_no, p.product_id, p.type_id, p.product_name, p.product_desc, p.product_price "
											 + "from products p where p.product_id = ?";
	
	static final String SELECT_PRODUCT_BY_TYPE = "select p.sr_no, p.product_id, p.type_id, p.product_name, p.product_desc, p.product_price "
			 								   + "from products p where p.type_id = ?";
	
	static final String SELECT_PRODUCT_BY_NAME = "select p.sr_no, p.product_id, p.type_id, p.product_name, p.product_desc, p.product_price "
			 								   + "from products p where p.product_name = ?";
	
	static final String SELECT_NEXT_N_PRODUCTS = "select p.sr_no, p.product_id, p.type_id, p.product_name, p.product_desc, p.product_price "
											   + "from products p where p.sr_no > ? order by p.sr_no limit ?";
	
	static final String SELECT_PREV_N_PRODUCTS = "select p.sr_no, p.product_id, p.type_id, p.product_name, p.product_desc, p.product_price "
											   + "from (select * from products where sr_no < ? order by sr_no desc limit ?) p order by p.sr_no";

	int insertProduct(Product product, Connection connection);
	int updateProduct(Product product, Connection connection);
	List<Product> selectAllProducts(Connection connection) throws SQLException;
	Product selectProductById(String productId, Connection connection) throws SQLException;
	List<Product> selectProductByType(String productType, Connection connection) throws SQLException;
	List<Product> selectProductByName(String productName, Connection connection) throws SQLException;
	List<Product> selectNextNProducts(int lastMaxSrNo, int pageSize, Connection connection) throws SQLException;
	List<Product> selectPrevNProducts(int lastMinSrNo, int pageSize, Connection connection) throws SQLException;
	
}
