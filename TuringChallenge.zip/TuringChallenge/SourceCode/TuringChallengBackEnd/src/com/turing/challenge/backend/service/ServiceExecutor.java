package com.turing.challenge.backend.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.turing.challenge.backend.order.service.AddUserOrder;
import com.turing.challenge.backend.order.service.SelectNextNOrders;
import com.turing.challenge.backend.order.service.SelectOrdersByStatus;
import com.turing.challenge.backend.order.service.SelectPrevNOrders;
import com.turing.challenge.backend.order.service.SelectUserOrders;
import com.turing.challenge.backend.order.service.SelectUserOrdersByStatus;
import com.turing.challenge.backend.order.service.UpdateUserOrderStatus;
import com.turing.challenge.backend.product.service.AddProduct;
import com.turing.challenge.backend.product.service.SelectAllProducts;
import com.turing.challenge.backend.product.service.SelectNextNProducts;
import com.turing.challenge.backend.product.service.SelectPrevNProducts;
import com.turing.challenge.backend.product.service.SelectProductById;
import com.turing.challenge.backend.product.service.SelectProductByName;
import com.turing.challenge.backend.product.service.SelectProductByType;
import com.turing.challenge.backend.product.service.UpdateProduct;
import com.turing.challenge.backend.user.service.AddUser;
import com.turing.challenge.backend.user.service.UpdateUser;
import com.turing.challenge.backend.user.service.ValidateUser;

public class ServiceExecutor {
	
	private static final Logger LOGGER = LogManager.getLogger(ServiceExecutor.class);
	
	public static String execute(String serviceId, String request) {
		
		try {
			
			AService service = null;
			
			switch(serviceId) {
				case "addUser":{
					service = new AddUser();
					break;
				}
				case "updateUser":{
					service = new UpdateUser();
					break;
				}
				case "validateUser":{
					service = new ValidateUser();
					break;
				}
				case "addProduct":{
					service = new AddProduct();
					break;
				}
				case "updateProduct":{
					service = new UpdateProduct();
					break;
				}
				case "getAllProducts":{
					service = new SelectAllProducts();
					break;
				}
				case "getProductById":{
					service = new SelectProductById();
					break;
				}
				case "getProductByType":{
					service = new SelectProductByType();
					break;
				}
				case "getProductByName":{
					service = new SelectProductByName();
					break;
				}
				case "getNextNProducts":{
					service = new SelectNextNProducts();
					break;
				}
				case "getPrevNProducts":{
					service = new SelectPrevNProducts();
					break;
				}
				case "addUserOrder":{
					service = new AddUserOrder();
					break;
				}
				case "updateUserOrderStatus":{
					service = new UpdateUserOrderStatus();
					break;
				}
				case "getUserOrders":{
					service = new SelectUserOrders();
					break;
				}
				case "getUserOrdersByStatus":{
					service = new SelectUserOrdersByStatus();
					break;
				}
				case "getOrdersByStatus":{
					service = new SelectOrdersByStatus();
					break;
				}
				case "getNextNOrders":{
					service = new SelectNextNOrders();
					break;
				}
				case "getPrevNOrders":{
					service = new SelectPrevNOrders();
					break;
				}
			}
			
			if(null != service) {
				return service.process(request);
			}
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in execute(), serviceId(" + serviceId + ")", e);
		}
		
		return "failure";
		
	}

}
