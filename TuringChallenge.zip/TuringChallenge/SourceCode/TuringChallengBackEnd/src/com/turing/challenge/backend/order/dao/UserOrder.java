package com.turing.challenge.backend.order.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserOrder {
	
	public UserOrder() {
		useOrderProducts = new ArrayList<UserOrderProduct>();
	}
	
	private int srNo;
	private long orderId;
	private String userId;
	private String orderStatus;
	private BigDecimal orderAmount;
	private Date createdAt;
	private Date updatedAt;
	
	private List<UserOrderProduct> useOrderProducts;

	
	public int getSrNo() {
		return srNo;
	}

	public void setSrNo(int srNo) {
		this.srNo = srNo;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public BigDecimal getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(BigDecimal orderAmount) {
		this.orderAmount = orderAmount;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public List<UserOrderProduct> getUseOrderProducts() {
		return useOrderProducts;
	}

	public void setUseOrderProducts(List<UserOrderProduct> useOrderProducts) {
		this.useOrderProducts = useOrderProducts;
	}

	@Override
	public String toString() {
		return "UserOrder [orderId=" + orderId + ", userId=" + userId + ", orderStatus=" + orderStatus
				+ ", orderAmount=" + orderAmount + ", useOrderProducts=" + useOrderProducts + "]";
	}

}
