package com.turing.challenge.backend.product.service;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.turing.challenge.backend.product.dao.Product;
import com.turing.challenge.backend.product.dao.ProductDaoImpl;
import com.turing.challenge.backend.service.AService;
import com.turing.challenge.backend.utils.DaoUtils;
import com.turing.challenge.backend.utils.MappingUtils;

public class SelectNextNProducts extends AService{

	private static final Logger LOGGER = LogManager.getLogger(SelectNextNProducts.class);
	
	@Override
	public String process(String request) throws JsonParseException, JsonMappingException, IOException {
		
		Product product = MappingUtils.OBJECT_MAPPER.readValue(request, Product.class);
		
		Connection con = DaoUtils.createConnection();
		
		try {
			
			List<Product> products = ProductDaoImpl.getInstance().selectNextNProducts(product.getSrNo(), 2, con);
			
			if(products.isEmpty()) {
				return "empty";
			}
			
			return MappingUtils.OBJECT_WRITER.writeValueAsString(products);
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in process()", e);
		}finally {
			DaoUtils.closeConnection(con);
		}
		
		return "failure";
		
	}

}
