package com.turing.challenge.backend.product.service;

import java.io.IOException;
import java.sql.Connection;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.turing.challenge.backend.product.dao.Product;
import com.turing.challenge.backend.product.dao.ProductDaoImpl;
import com.turing.challenge.backend.service.AService;
import com.turing.challenge.backend.utils.DaoUtils;
import com.turing.challenge.backend.utils.MappingUtils;

public class UpdateProduct extends AService{

	@Override
	public String process(String request) throws JsonParseException, JsonMappingException, IOException {
		
		Product product = MappingUtils.OBJECT_MAPPER.readValue(request, Product.class);
		
		Connection con = DaoUtils.createConnection();
		
		int rowsInserted = ProductDaoImpl.getInstance().updateProduct(product, con);
		
		DaoUtils.closeConnection(con);
		
		return rowsInserted > 0 ? "success" : "failure";
	}

}
