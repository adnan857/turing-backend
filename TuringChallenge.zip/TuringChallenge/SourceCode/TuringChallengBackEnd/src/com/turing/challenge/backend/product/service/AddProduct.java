package com.turing.challenge.backend.product.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.turing.challenge.backend.product.dao.Product;
import com.turing.challenge.backend.product.dao.ProductDaoImpl;
import com.turing.challenge.backend.service.AService;
import com.turing.challenge.backend.utils.DaoUtils;
import com.turing.challenge.backend.utils.MappingUtils;

public class AddProduct extends AService{
	
	private static final Logger LOGGER = LogManager.getLogger(AddProduct.class);

	@Override
	public String process(String request) throws JsonParseException, JsonMappingException, IOException {
		
		Product product = MappingUtils.OBJECT_MAPPER.readValue(request, Product.class);
		
		Connection con = DaoUtils.createConnection();
		
		try {
			Product _product = ProductDaoImpl.getInstance().selectProductById(product.getProductId(), con);
			if(null != _product) {
				DaoUtils.closeConnection(con);
				return "exist";
			}
		}catch(SQLException e) {
			LOGGER.error("Exception occurred in process()", e);
			DaoUtils.closeConnection(con);
			return "failure";
		}
		
		int rowsInserted = ProductDaoImpl.getInstance().insertProduct(product, con);
		
		DaoUtils.closeConnection(con);
		
		return rowsInserted > 0 ? "success" : "failure";
	}

}
