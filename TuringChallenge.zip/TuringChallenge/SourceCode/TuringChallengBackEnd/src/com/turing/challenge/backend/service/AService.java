package com.turing.challenge.backend.service;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;

public abstract class AService {
	
	public abstract String process(String request) throws JsonParseException, JsonMappingException, IOException;

}
