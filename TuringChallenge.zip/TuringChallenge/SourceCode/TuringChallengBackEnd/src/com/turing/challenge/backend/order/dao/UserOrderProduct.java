package com.turing.challenge.backend.order.dao;

import java.math.BigDecimal;

public class UserOrderProduct {
	
	private long orderId;
	private String productId;
	private BigDecimal productPrice;
	private int quantity;

	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	public BigDecimal getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(BigDecimal productPrice) {
		this.productPrice = productPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "UserOrderProduct [productId=" + productId + ", productPrice=" + productPrice + ", quantity=" + quantity
				+ "]";
	}

}
