package com.turing.challenge.backend.user.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.turing.challenge.backend.service.AService;
import com.turing.challenge.backend.user.dao.User;
import com.turing.challenge.backend.user.dao.UserDaoImpl;
import com.turing.challenge.backend.utils.DaoUtils;
import com.turing.challenge.backend.utils.MappingUtils;

public class ValidateUser extends AService{
	
	private static final Logger LOGGER = LogManager.getLogger(AddUser.class);

	@Override
	public String process(String request) throws JsonParseException, JsonMappingException, IOException {
		
		User user = MappingUtils.OBJECT_MAPPER.readValue(request, User.class);
		
		Connection con = DaoUtils.createConnection();
		
		try {
			User _user = UserDaoImpl.getInstance().selectUser(user.getUserId(), con);
			if(null != _user && user.getPassword().equals(_user.getPassword())) {
				DaoUtils.closeConnection(con);
				return MappingUtils.OBJECT_WRITER.writeValueAsString(_user);
			}
			return "USR_01";
		}catch(SQLException e) {
			LOGGER.error("Exception occurred in process()", e);
			DaoUtils.closeConnection(con);
			return "failure";
		}
		
	}

}
