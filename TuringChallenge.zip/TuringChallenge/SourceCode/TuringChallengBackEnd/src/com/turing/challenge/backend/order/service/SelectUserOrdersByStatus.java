package com.turing.challenge.backend.order.service;

import java.io.IOException;
import java.sql.Connection;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.turing.challenge.backend.order.dao.UserOrder;
import com.turing.challenge.backend.order.dao.UserOrderDaoImpl;
import com.turing.challenge.backend.service.AService;
import com.turing.challenge.backend.utils.DaoUtils;
import com.turing.challenge.backend.utils.MappingUtils;

public class SelectUserOrdersByStatus extends AService{

	private static final Logger LOGGER = LogManager.getLogger(SelectUserOrdersByStatus.class);
	
	@Override
	public String process(String request) throws JsonParseException, JsonMappingException, IOException {
		
		UserOrder userOrder = MappingUtils.OBJECT_MAPPER.readValue(request, UserOrder.class);
		
		Connection con = DaoUtils.createConnection();
		
		try {
			
			List<UserOrder> userOrders = UserOrderDaoImpl.getInstance().selectUserOrdersByStatus(userOrder.getUserId(), userOrder.getOrderStatus(), con);
			
			if(userOrders.isEmpty()) {
				return "empty";
			}
			
			return MappingUtils.OBJECT_WRITER.writeValueAsString(userOrders);
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in process()", e);
		}finally {
			DaoUtils.closeConnection(con);
		}
		
		return "failure";
		
	}

}
