package com.turing.challenge.backend.product.service;

import java.io.IOException;
import java.sql.Connection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.turing.challenge.backend.product.dao.Product;
import com.turing.challenge.backend.product.dao.ProductDaoImpl;
import com.turing.challenge.backend.service.AService;
import com.turing.challenge.backend.utils.DaoUtils;
import com.turing.challenge.backend.utils.MappingUtils;

public class SelectProductById extends AService{

	private static final Logger LOGGER = LogManager.getLogger(SelectProductById.class);
	
	@Override
	public String process(String request) throws JsonParseException, JsonMappingException, IOException {
		
		Product product = MappingUtils.OBJECT_MAPPER.readValue(request, Product.class);
		
		Connection con = DaoUtils.createConnection();
		
		try {
			
			Product _product = ProductDaoImpl.getInstance().selectProductById(product.getProductId(), con);
			
			if(null == _product) {
				return "empty";
			}
			
			return MappingUtils.OBJECT_WRITER.writeValueAsString(_product);
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in process()", e);
		}finally {
			DaoUtils.closeConnection(con);
		}
		
		return "failure";
		
	}

}
