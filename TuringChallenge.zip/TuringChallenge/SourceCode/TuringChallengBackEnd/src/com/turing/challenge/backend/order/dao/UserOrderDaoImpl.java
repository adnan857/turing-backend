package com.turing.challenge.backend.order.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.turing.challenge.backend.utils.DaoUtils;

public final class UserOrderDaoImpl implements IUserOrderDao {
	
	private static final Logger LOGGER = LogManager.getLogger(UserOrderDaoImpl.class);
	
	private static final UserOrderDaoImpl instance = new UserOrderDaoImpl();
	
	private UserOrderDaoImpl(){
		
	}
	
	public static UserOrderDaoImpl getInstance() {
		return instance;
	}
	
	@Override
	public int insertUserOrder(UserOrder userOrder, Connection connection) {
		// TODO Auto-generated method stub
		
		int idx = 0;
		PreparedStatement ps = null;
		
		try {
			
			ps = connection.prepareStatement(INSERT_USER_ORDER);
			ps.setLong(++idx, userOrder.getOrderId());
			ps.setString(++idx, userOrder.getUserId());
			ps.setString(++idx, userOrder.getOrderStatus());
			ps.setBigDecimal(++idx, userOrder.getOrderAmount());
			
			return ps.executeUpdate();
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in insertUserOrder()", e);
		}finally {
			DaoUtils.closePreparedStatement(ps);
		}
		
		return 0;
	}

	@Override
	public int insertUserOrderProduct(UserOrderProduct userOrderProduct, Connection connection) {
		// TODO Auto-generated method stub
		
		int idx = 0;
		PreparedStatement ps = null;
		
		try {
			
			ps = connection.prepareStatement(INSERT_USER_ORDER_PRODUCT);
			ps.setLong(++idx, userOrderProduct.getOrderId());
			ps.setString(++idx, userOrderProduct.getProductId());
			ps.setBigDecimal(++idx, userOrderProduct.getProductPrice());
			ps.setInt(++idx, userOrderProduct.getQuantity());
			
			return ps.executeUpdate();
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in insertUserOrderProduct()", e);
		}finally {
			DaoUtils.closePreparedStatement(ps);
		}
		
		return 0;
	}

	@Override
	public int updateUserOrderStatus(long orderId, String orderStatus, Connection connection) {
		// TODO Auto-generated method stub
		
		PreparedStatement ps = null;
		
		try {
			
			ps = connection.prepareStatement(UPDATE_USER_ORDER_STATUS);
			ps.setString(1, orderStatus);
			ps.setLong(2, orderId);
			
			return ps.executeUpdate();
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in insertUserOrderProduct()", e);
		}finally {
			DaoUtils.closePreparedStatement(ps);
		}
		
		return 0;
	}

	@Override
	public List<UserOrder> selectUserOrders(String userId, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		List<UserOrder> userOrders = new ArrayList<UserOrder>();
		
		Map<Long, UserOrder> userOrdersMap = new ConcurrentHashMap<Long, UserOrder>();
		UserOrder userOrder = null;
		long orderId = 0;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_USER_ORDERS);
			ps.setString(1, userId);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				orderId = rs.getLong("order_id");
				userOrder = userOrdersMap.get(orderId);
				
				if(null == userOrder) {
					userOrder = new UserOrder();
					userOrder.setSrNo(rs.getInt("sr_no"));
					userOrder.setOrderId(orderId);
					userOrder.setUserId(rs.getString("user_id"));
					userOrder.setOrderStatus(rs.getString("order_status"));
					userOrder.setOrderAmount(rs.getBigDecimal("order_amount"));
					userOrdersMap.put(orderId, userOrder);
					userOrders.add(userOrder);
				}
				
				UserOrderProduct uop = new UserOrderProduct();
				uop.setOrderId(orderId);
				uop.setProductId(rs.getString("product_id"));
				uop.setProductPrice(rs.getBigDecimal("product_price"));
				uop.setQuantity(rs.getInt("quantity"));
				
				userOrder.getUseOrderProducts().add(uop);
				
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return userOrders;
	}

	@Override
	public List<UserOrder> selectUserOrdersByStatus(String userId, String orderStatus, Connection connection)
			throws SQLException {
		// TODO Auto-generated method stub
		
		List<UserOrder> userOrders = new ArrayList<UserOrder>();
		
		Map<Long, UserOrder> userOrdersMap = new ConcurrentHashMap<Long, UserOrder>();
		UserOrder userOrder = null;
		long orderId = 0;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_USER_ORDERS_BY_STATUS);
			ps.setString(1, userId);
			ps.setString(2, orderStatus);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				orderId = rs.getLong("order_id");
				userOrder = userOrdersMap.get(orderId);
				
				if(null == userOrder) {
					userOrder = new UserOrder();
					userOrder.setSrNo(rs.getInt("sr_no"));
					userOrder.setOrderId(orderId);
					userOrder.setUserId(rs.getString("user_id"));
					userOrder.setOrderStatus(rs.getString("order_status"));
					userOrder.setOrderAmount(rs.getBigDecimal("order_amount"));
					userOrdersMap.put(orderId, userOrder);
					userOrders.add(userOrder);
				}
				
				UserOrderProduct uop = new UserOrderProduct();
				uop.setOrderId(orderId);
				uop.setProductId(rs.getString("product_id"));
				uop.setProductPrice(rs.getBigDecimal("product_price"));
				uop.setQuantity(rs.getInt("quantity"));
				
				userOrder.getUseOrderProducts().add(uop);
				
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return userOrders;
	}

	@Override
	public List<UserOrder> selectOrdersByStatus(String orderStatus, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		List<UserOrder> userOrders = new ArrayList<UserOrder>();
		
		Map<Long, UserOrder> userOrdersMap = new ConcurrentHashMap<Long, UserOrder>();
		UserOrder userOrder = null;
		long orderId = 0;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_ORDERS_BY_STATUS);
			ps.setString(1, orderStatus);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				orderId = rs.getLong("order_id");
				userOrder = userOrdersMap.get(orderId);
				
				if(null == userOrder) {
					userOrder = new UserOrder();
					userOrder.setSrNo(rs.getInt("sr_no"));
					userOrder.setOrderId(orderId);
					userOrder.setUserId(rs.getString("user_id"));
					userOrder.setOrderStatus(rs.getString("order_status"));
					userOrder.setOrderAmount(rs.getBigDecimal("order_amount"));
					userOrdersMap.put(orderId, userOrder);
					userOrders.add(userOrder);
				}
				
				UserOrderProduct uop = new UserOrderProduct();
				uop.setOrderId(orderId);
				uop.setProductId(rs.getString("product_id"));
				uop.setProductPrice(rs.getBigDecimal("product_price"));
				uop.setQuantity(rs.getInt("quantity"));
				
				userOrder.getUseOrderProducts().add(uop);
				
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return userOrders;
	}

	@Override
	public List<UserOrder> selectNextNOrders(int lastMaxSrNo, String userId,  int pageSize, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		List<UserOrder> userOrders = new ArrayList<UserOrder>();
		
		Map<Long, UserOrder> userOrdersMap = new ConcurrentHashMap<Long, UserOrder>();
		UserOrder userOrder = null;
		long orderId = 0;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_NEXT_N_ORDERS);
			ps.setInt(1, lastMaxSrNo);
			ps.setString(2, userId);
			ps.setInt(3, pageSize);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				orderId = rs.getLong("order_id");
				userOrder = userOrdersMap.get(orderId);
				
				if(null == userOrder) {
					userOrder = new UserOrder();
					userOrder.setSrNo(rs.getInt("sr_no"));
					userOrder.setOrderId(orderId);
					userOrder.setUserId(rs.getString("user_id"));
					userOrder.setOrderStatus(rs.getString("order_status"));
					userOrder.setOrderAmount(rs.getBigDecimal("order_amount"));
					userOrdersMap.put(orderId, userOrder);
					userOrders.add(userOrder);
				}
				
				UserOrderProduct uop = new UserOrderProduct();
				uop.setOrderId(orderId);
				uop.setProductId(rs.getString("product_id"));
				uop.setProductPrice(rs.getBigDecimal("product_price"));
				uop.setQuantity(rs.getInt("quantity"));
				
				userOrder.getUseOrderProducts().add(uop);
				
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return userOrders;
	}

	@Override
	public List<UserOrder> selectPrevNOrders(int lastMinSrNo, String userId,  int pageSize, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		List<UserOrder> userOrders = new ArrayList<UserOrder>();
		
		Map<Long, UserOrder> userOrdersMap = new ConcurrentHashMap<Long, UserOrder>();
		UserOrder userOrder = null;
		long orderId = 0;
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_PREV_N_ORDERS);
			ps.setInt(1, lastMinSrNo);
			ps.setString(2, userId);
			ps.setInt(3, pageSize);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				
				orderId = rs.getLong("order_id");
				userOrder = userOrdersMap.get(orderId);
				
				if(null == userOrder) {
					userOrder = new UserOrder();
					userOrder.setSrNo(rs.getInt("sr_no"));
					userOrder.setOrderId(orderId);
					userOrder.setUserId(rs.getString("user_id"));
					userOrder.setOrderStatus(rs.getString("order_status"));
					userOrder.setOrderAmount(rs.getBigDecimal("order_amount"));
					userOrdersMap.put(orderId, userOrder);
					userOrders.add(userOrder);
				}
				
				UserOrderProduct uop = new UserOrderProduct();
				uop.setOrderId(orderId);
				uop.setProductId(rs.getString("product_id"));
				uop.setProductPrice(rs.getBigDecimal("product_price"));
				uop.setQuantity(rs.getInt("quantity"));
				
				userOrder.getUseOrderProducts().add(uop);
				
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return userOrders;
	}

}
