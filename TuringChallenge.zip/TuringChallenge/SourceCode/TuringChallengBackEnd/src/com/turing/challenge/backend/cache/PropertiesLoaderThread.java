package com.turing.challenge.backend.cache;

public class PropertiesLoaderThread implements Runnable{

	private PropertiesLoaderThread() {
		new Thread(this).start();
	}
	
	private static final PropertiesLoaderThread instance = new PropertiesLoaderThread();
	
	public static PropertiesLoaderThread getInstance() {
		return instance;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		while(true) {
			
			PropertiesManager.getInstance().loadProperties(null);
			
			try {
				Thread.sleep(1000 * 30 * 5);
			} catch (InterruptedException e) {

			}
			
		}
		
	}

}
