package com.turing.challenge.backend.user.dao;

import java.sql.Connection;
import java.sql.SQLException;

public interface IUserDao {
	
	static final String INSERT_USER = "insert into users (user_id, password, first_name, last_name, email, created_at) "
									+ "values (?, hex(aes_encrypt(?, SHA2(?,512))), ?, ?, ?, now())";
	
	static final String UPDATE_USER = "update users set password = hex(aes_encrypt(?, SHA2(?,512))), first_name = ?, last_name = ?, email = ?, "
									+ "updated_at = now() where user_id = ?";
	
	static final String SELECT_USER = "select u.user_id, convert(aes_decrypt(unhex(u.password), SHA2(?,512)) using utf8) as password, u.first_name, "
									+ "u.last_name, u.email from users u where user_id = ?";
	
	int insertUser(User user, Connection connection);
	int updateUser(User user, Connection connection);
	User selectUser(String userId, Connection connection) throws SQLException;

}
