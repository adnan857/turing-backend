package com.turing.challenge.backend.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.turing.challenge.backend.utils.DaoUtils;

public final class ProductDaoImpl implements IProductDao {

	private static final Logger LOGGER = LogManager.getLogger(ProductDaoImpl.class);
	
	private static final ProductDaoImpl instance = new ProductDaoImpl();
	
	private ProductDaoImpl(){
		
	}
	
	public static ProductDaoImpl getInstance() {
		return instance;
	}
	
	@Override
	public int insertProduct(Product product, Connection connection) {
		// TODO Auto-generated method stub
		
		int idx = 0;
		PreparedStatement ps = null;
		
		try {
			
			ps = connection.prepareStatement(INSERT_PRODUCT);
			ps.setString(++idx, product.getProductId());
			ps.setString(++idx, product.getTypeId());
			ps.setString(++idx, product.getProductName());
			ps.setString(++idx, product.getProductDesc());
			ps.setBigDecimal(++idx, product.getProductPrice());
			
			return ps.executeUpdate();
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in insertProduct()", e);
		}finally {
			DaoUtils.closePreparedStatement(ps);
		}
		
		return 0;
	}

	@Override
	public int updateProduct(Product product, Connection connection) {
		// TODO Auto-generated method stub
		
		int idx = 0;
		PreparedStatement ps = null;
		
		try {
			
			ps = connection.prepareStatement(UPDATE_PRODUCT);
			ps.setString(++idx, product.getTypeId());
			ps.setString(++idx, product.getProductName());
			ps.setString(++idx, product.getProductDesc());
			ps.setBigDecimal(++idx, product.getProductPrice());
			ps.setString(++idx, product.getProductId());
			
			return ps.executeUpdate();
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in updateProduct()", e);
		}finally {
			DaoUtils.closePreparedStatement(ps);
		}
		
		return 0;
	}
	
	@Override
	public List<Product> selectAllProducts(Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		List<Product> products = new ArrayList<Product>();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_ALL_PRODUCTS);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Product product = new Product();
				product.setSrNo(rs.getInt("sr_no"));
				product.setProductId(rs.getString("product_id"));
				product.setTypeId(rs.getString("type_id"));
				product.setProductName(rs.getString("product_name"));
				product.setProductDesc(rs.getString("product_desc"));
				product.setProductPrice(rs.getBigDecimal("product_price"));
				products.add(product);
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return products;
	}

	@Override
	public Product selectProductById(String productId, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_PRODUCT_BY_ID);
			ps.setString(1, productId);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				Product product = new Product();
				product.setSrNo(rs.getInt("sr_no"));
				product.setProductId(rs.getString("product_id"));
				product.setTypeId(rs.getString("type_id"));
				product.setProductName(rs.getString("product_name"));
				product.setProductDesc(rs.getString("product_desc"));
				product.setProductPrice(rs.getBigDecimal("product_price"));
				return product;
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return null;
	}

	@Override
	public List<Product> selectProductByType(String productType, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		List<Product> products = new ArrayList<Product>();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_PRODUCT_BY_TYPE);
			ps.setString(1, productType);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Product product = new Product();
				product.setSrNo(rs.getInt("sr_no"));
				product.setProductId(rs.getString("product_id"));
				product.setTypeId(rs.getString("type_id"));
				product.setProductName(rs.getString("product_name"));
				product.setProductDesc(rs.getString("product_desc"));
				product.setProductPrice(rs.getBigDecimal("product_price"));
				products.add(product);
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return products;
	}

	@Override
	public List<Product> selectProductByName(String productName, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		List<Product> products = new ArrayList<Product>();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_PRODUCT_BY_NAME);
			ps.setString(1, productName);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Product product = new Product();
				product.setSrNo(rs.getInt("sr_no"));
				product.setProductId(rs.getString("product_id"));
				product.setTypeId(rs.getString("type_id"));
				product.setProductName(rs.getString("product_name"));
				product.setProductDesc(rs.getString("product_desc"));
				product.setProductPrice(rs.getBigDecimal("product_price"));
				products.add(product);
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return products;
	}

	@Override
	public List<Product> selectNextNProducts(int lastMaxSrNo, int pageSize, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		List<Product> products = new ArrayList<Product>();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_NEXT_N_PRODUCTS);
			ps.setInt(1, lastMaxSrNo);
			ps.setInt(2, pageSize);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Product product = new Product();
				product.setSrNo(rs.getInt("sr_no"));
				product.setProductId(rs.getString("product_id"));
				product.setTypeId(rs.getString("type_id"));
				product.setProductName(rs.getString("product_name"));
				product.setProductDesc(rs.getString("product_desc"));
				product.setProductPrice(rs.getBigDecimal("product_price"));
				products.add(product);
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return products;
	}

	@Override
	public List<Product> selectPrevNProducts(int lastMinSrNo, int pageSize, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		List<Product> products = new ArrayList<Product>();
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_PREV_N_PRODUCTS);
			ps.setInt(1, lastMinSrNo);
			ps.setInt(2, pageSize);
			
			rs = ps.executeQuery();
			
			while(rs.next()) {
				Product product = new Product();
				product.setSrNo(rs.getInt("sr_no"));
				product.setProductId(rs.getString("product_id"));
				product.setTypeId(rs.getString("type_id"));
				product.setProductName(rs.getString("product_name"));
				product.setProductDesc(rs.getString("product_desc"));
				product.setProductPrice(rs.getBigDecimal("product_price"));
				products.add(product);
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return products;
	}

}
