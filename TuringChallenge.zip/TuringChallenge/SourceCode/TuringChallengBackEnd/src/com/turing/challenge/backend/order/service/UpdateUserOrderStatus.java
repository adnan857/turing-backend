package com.turing.challenge.backend.order.service;

import java.io.IOException;
import java.sql.Connection;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.turing.challenge.backend.order.dao.UserOrder;
import com.turing.challenge.backend.order.dao.UserOrderDaoImpl;
import com.turing.challenge.backend.service.AService;
import com.turing.challenge.backend.utils.DaoUtils;
import com.turing.challenge.backend.utils.MappingUtils;

public class UpdateUserOrderStatus extends AService{

	@Override
	public String process(String request) throws JsonParseException, JsonMappingException, IOException {
		
		UserOrder userOrder = MappingUtils.OBJECT_MAPPER.readValue(request, UserOrder.class);
		
		Connection con = DaoUtils.createConnection();
		
		int rowsInserted = UserOrderDaoImpl.getInstance().updateUserOrderStatus(userOrder.getOrderId(), userOrder.getOrderStatus(), con);
		
		DaoUtils.closeConnection(con);
		
		return rowsInserted > 0 ? "success" : "failure";
	}

}
