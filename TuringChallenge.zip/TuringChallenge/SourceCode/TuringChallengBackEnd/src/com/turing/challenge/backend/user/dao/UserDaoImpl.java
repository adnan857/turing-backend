package com.turing.challenge.backend.user.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.turing.challenge.backend.cache.PropertiesManager;
import com.turing.challenge.backend.utils.DaoUtils;

public final class UserDaoImpl implements IUserDao{
	
	private static final Logger LOGGER = LogManager.getLogger(UserDaoImpl.class);
	
	private static final UserDaoImpl instance = new UserDaoImpl();
	
	private static final PropertiesManager propertiesManager = PropertiesManager.getInstance();
	
	private UserDaoImpl(){
		
	}
	
	public static UserDaoImpl getInstance() {
		return instance;
	}

	@Override
	public int insertUser(User user, Connection connection) {
		// TODO Auto-generated method stub
		
		int idx = 0;
		PreparedStatement ps = null;
		
		try {
			
			ps = connection.prepareStatement(INSERT_USER);
			ps.setString(++idx, user.getUserId());
			ps.setString(++idx, user.getPassword());
			ps.setString(++idx, propertiesManager.getStringValue("encrKey", "turingEncrKey"));
			ps.setString(++idx, user.getFirstName());
			ps.setString(++idx, user.getLastName());
			ps.setString(++idx, user.getEmail());
			
			return ps.executeUpdate();
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in insertUser()", e);
		}finally {
			DaoUtils.closePreparedStatement(ps);
		}
		
		return 0;
	}

	@Override
	public int updateUser(User user, Connection connection) {
		// TODO Auto-generated method stub
		
		int idx = 0;
		PreparedStatement ps = null;
		
		try {
			
			ps = connection.prepareStatement(UPDATE_USER);
			ps.setString(++idx, user.getPassword());
			ps.setString(++idx, propertiesManager.getStringValue("encrKey", "turingEncrKey"));
			ps.setString(++idx, user.getFirstName());
			ps.setString(++idx, user.getLastName());
			ps.setString(++idx, user.getEmail());
			ps.setString(++idx, user.getUserId());
			
			return ps.executeUpdate();
			
		}catch(Exception e) {
			LOGGER.error("Exception occurred in updateUser()", e);
		}finally {
			DaoUtils.closePreparedStatement(ps);
		}
		
		return 0;
	}

	@Override
	public User selectUser(String userId, Connection connection) throws SQLException {
		// TODO Auto-generated method stub
		
		PreparedStatement ps = null;
		ResultSet rs = null;
		
		try {
			
			ps = connection.prepareStatement(SELECT_USER);
			ps.setString(1, propertiesManager.getStringValue("encrKey", "turingEncrKey"));
			ps.setString(2, userId);
			
			rs = ps.executeQuery();
			
			if(rs.next()) {
				User user = new User();
				user.setUserId(rs.getString("user_id"));
				user.setPassword(rs.getString("password"));
				user.setFirstName(rs.getString("first_name"));
				user.setLastName(rs.getString("last_name"));
				user.setEmail(rs.getString("email"));
				return user;
			}
			
		}finally {
			DaoUtils.closeResultSet(rs);
			DaoUtils.closePreparedStatement(ps);
		}
		
		return null;
	}

}
