package com.turing.challenge.backend.order.service;

import java.io.IOException;
import java.sql.Connection;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.turing.challenge.backend.cache.PropertiesManager;
import com.turing.challenge.backend.order.dao.UserOrder;
import com.turing.challenge.backend.order.dao.UserOrderDaoImpl;
import com.turing.challenge.backend.order.dao.UserOrderProduct;
import com.turing.challenge.backend.service.AService;
import com.turing.challenge.backend.user.dao.User;
import com.turing.challenge.backend.user.dao.UserDaoImpl;
import com.turing.challenge.backend.utils.DaoUtils;
import com.turing.challenge.backend.utils.EmailServiceImpl;
import com.turing.challenge.backend.utils.MappingUtils;
import com.turing.challenge.backend.utils.Utils;

public class AddUserOrder extends AService{
	
	private static final Logger LOGGER = LogManager.getLogger(AddUserOrder.class);

	@Override
	public String process(String request) throws JsonParseException, JsonMappingException, IOException {
		
		UserOrder userOrder = MappingUtils.OBJECT_MAPPER.readValue(request, UserOrder.class);

		if(userOrder.getUseOrderProducts().isEmpty()) {
			LOGGER.warn("userOrderProducts is empty");
			return "failure";
		}
		
		userOrder.setOrderId(Utils.generateId());
		
		Connection con = DaoUtils.createConnection();
		
		try {
			
			DaoUtils.setAutoCommit(con, false);
		
			int rowsInserted = UserOrderDaoImpl.getInstance().insertUserOrder(userOrder, con);
			
			if(rowsInserted <= 0) {
				
				DaoUtils.rollBack(con);
				return "failure";
				
			}else {
				
				for(UserOrderProduct uop : userOrder.getUseOrderProducts()) {
					uop.setOrderId(userOrder.getOrderId());
					if(UserOrderDaoImpl.getInstance().insertUserOrderProduct(uop, con) <= 0) {
						DaoUtils.rollBack(con);
						return "failure";
					}
				}
				
				if("Y".equals(PropertiesManager.getInstance().getStringValue("sendAlert", "N"))) {
				
					User _user = UserDaoImpl.getInstance().selectUser(userOrder.getUserId(), con);
					
					EmailServiceImpl.getInstance().send("adnan857@gmail.com", _user.getEmail(), null, null, "Order Added Successfully", createBody(_user.getFirstName(), userOrder));
					
				}
				
				DaoUtils.commit(con);
				return "success";
				
			}
		
		}catch(Exception e) {
			LOGGER.error("Exception occurred in process()", e);
			DaoUtils.rollBack(con);
			return "failure";
		}catch(Throwable t) {
			LOGGER.error("Throwable occurred in process()", t);
			DaoUtils.rollBack(con);
			return "failure";
		}finally {
			DaoUtils.setAutoCommit(con, true);
			DaoUtils.closeConnection(con);
		}
		
	}
	
	private String createBody(String firstName, UserOrder userOrder) {
		return "Hi " + firstName + ", \n\nYour order has been place successfully\n\n" + userOrder + "\n\nRegards\nTuring Team";
	}

}
