package com.turing.challenge.backend.utils;

import java.util.Date;

public class Utils {
	
	private static Integer counter = 1;
	
	public static long generateId() {
		
		synchronized(counter) {
			if(counter > 9999) {
				counter = 1;
			}
			return Long.parseLong(new Date().getTime() + "00" + (++counter));
		}
		
	}

}
