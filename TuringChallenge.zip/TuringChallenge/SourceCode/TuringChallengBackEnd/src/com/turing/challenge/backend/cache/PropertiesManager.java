package com.turing.challenge.backend.cache;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.apache.logging.log4j.Logger;

import org.apache.logging.log4j.LogManager;

public final class PropertiesManager {
	
	private static final Logger LOGGER 				= LogManager.getLogger(PropertiesManager.class);
	
	private static final Properties PROPERTIES		= new Properties();
		
	private static final PropertiesManager INSTANCE 	= new PropertiesManager();
	
	private PropertiesManager(){
		
	}
	
	private String filePath = null;
	
	public static PropertiesManager getInstance(){
		return INSTANCE;
	}

	public void loadProperties(String filePath){
		
		if(null != filePath) {
			this.filePath = filePath;
		}
		
		try{
			
			FileInputStream fis = new FileInputStream(new File(this.filePath));
			
			PROPERTIES.load(fis);
			
			LOGGER.info("Properties loaded...");
			
		}catch(Exception e){
			
			LOGGER.error("Exception occurred while loading properties.", e);
			
		}
	}

	
	public String getStringValue(String key, String defaultValue) {
		
		return PROPERTIES.getProperty(key, defaultValue);
		
	}
	
	public int getIntValue(String key, String defaultValue) {
		
		return Integer.parseInt(PROPERTIES.getProperty(key, defaultValue));
		
	}

	public long getLongValue(String key, String defaultValue) {
	
		return Long.parseLong(PROPERTIES.getProperty(key, defaultValue));
	
	}

}
