package com.turing.challenge.backend.utils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;

public class MappingUtils {
	
	public static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
	public static final ObjectWriter OBJECT_WRITER = new ObjectMapper().writer();

}
