function isEmptyOrNullTrimmed(text){
	if(null == text || "" == text.trim()){
		return true;
	}else{
		return false;
	}
}

function logConsoleMessage(message){
	console.log(new Date() + ", Message: " + message);
}

function add(e, sign){
	
	var row = e.closest('tr');
	
	var myOrder = localStorage.getItem('myOrder');
	
	if(null == myOrder){
		if(1 == sign){
			myOrder = new Map();
			myOrder[row.cells[1].innerHTML] = {'productId': row.cells[1].innerHTML, 'productPrice': row.cells[5].innerHTML, 'quantity': 1};
			localStorage.setItem('myOrder', JSON.stringify(myOrder));
		}
	}else{
		myOrder = JSON.parse(myOrder);
		var entry = myOrder[row.cells[1].innerHTML];
		if(null == entry){
			if(1 == sign){
				myOrder[row.cells[1].innerHTML] = {'productId': row.cells[1].innerHTML, 'productPrice': row.cells[5].innerHTML, 'quantity': 1};
			}
		}else{
			entry['quantity'] = entry['quantity'] + sign;
			if(0 == entry['quantity']){
				delete myOrder[row.cells[1].innerHTML];
			}
		}
		localStorage.setItem('myOrder', JSON.stringify(myOrder));
	}
  
	var orderAmount = 0;

	var size = 0;
	
	for (var key in myOrder) {
		var product = myOrder[key];
		orderAmount = ((orderAmount) + (product.productPrice * product.quantity));
		size = size + 1;
	}  
	
	if(0 == size){
		clearBucket();
		return;
	}
	
	populateOrderData(orderAmount);
	
}

function populateOrderData(orderAmount){

		var table = document.getElementById("myOrder");
		
		table.innerHTML = "";
		
		var tabHtml = '';
		
		tabHtml = tabHtml + '<table><tr><td>Sr No.</td>';
		tabHtml = tabHtml + '<td>Order ID</td>';
		tabHtml = tabHtml + '<td>Order Status</td>';
		tabHtml = tabHtml + '<td>Order Amount</td></tr>';
			
		tabHtml = tabHtml + '<tr><td>???</td><td>???</td><td>INIT</td><td>';
		tabHtml = tabHtml + orderAmount + '</td></tr>';
		
		tabHtml = tabHtml + '<tr><td>Product ID</td>';
		tabHtml = tabHtml + '<td>Product Price</td>';
		tabHtml = tabHtml + '<td>Quantity</td></tr>';
		
		var myOrder = JSON.parse(localStorage.getItem('myOrder'));
		
		for (var key in myOrder) {
			
			var product = myOrder[key];
			
			tabHtml = tabHtml + '<tr><td>' + product.productId + '</td><td>';
			tabHtml = tabHtml + product.productPrice + '</td><td>';
			tabHtml = tabHtml + product.quantity + '</td></tr>';
		}
		
		table.innerHTML = tabHtml + '</table>';

}

function populateProductsData(message){

	switch(message){
		case 'empty':{
			alert('I am sorry, No data found.');
			break;
		}
		case 'failure':{
			alert('I am sorry, your request could not be processed.');
			loginSuccessful();
			break;
		}
		default :{
			
			var _message = JSON.parse(message);
			
			var table = document.getElementById("productsList");
			
			table.innerHTML = "";
			
			var tabHtml = '';
			
			tabHtml = tabHtml + '<table id="productsTable"><tr><td>Sr No.</td><td>';
			tabHtml = tabHtml + 'Product ID</td><td>';
			tabHtml = tabHtml + 'Type ID</td><td>';
			tabHtml = tabHtml + 'Product Name</td><td>';
			tabHtml = tabHtml + 'Product Desc</td><td>';
			tabHtml = tabHtml + 'Product Price</td><td>';
			tabHtml = tabHtml + 'Action</td><td>';
			tabHtml = tabHtml + 'Action</td></tr>';
			
			localStorage.setItem('firstProduct', JSON.stringify({'srNo': _message[0].srNo}));
			localStorage.setItem('lastProduct', JSON.stringify({'srNo': _message[_message.length - 1].srNo}));
			
			for(var i = 0; i < _message.length; i++){
				
				tabHtml = tabHtml + '<tr><td>' + _message[i].srNo + '</td><td>';
				tabHtml = tabHtml + _message[i].productId + '</td><td>';
				tabHtml = tabHtml + _message[i].typeId + '</td><td>';
				tabHtml = tabHtml + _message[i].productName + '</td><td>';
				tabHtml = tabHtml + _message[i].productDesc + '</td><td>';
				tabHtml = tabHtml + _message[i].productPrice + '</td><td id="add' + i + '">';
				tabHtml = tabHtml + 'Add</td><td id="rem' + i + '">';
				tabHtml = tabHtml + 'Remove</td></tr>';
				
			}
			
			table.innerHTML = tabHtml + '</table>';
			
			for(var i = 0; i < _message.length; i++){
				document.getElementById('add' + i).setAttribute('onclick', 'add(this, 1);');
				document.getElementById('rem' + i).setAttribute('onclick', 'add(this, -1);');
			}
			
			newOrderPage();
			
			break;
		}
	}

}


function populateAllOrdersData(message){

	switch(message){
		case 'empty':{
			alert('I am sorry, No data found.');
			break;
		}
		case 'failure':{
			alert('I am sorry, your request could not be processed.');
			loginSuccessful();
			break;
		}
		default :{
			
			var _message = JSON.parse(message);
			
			var table = document.getElementById("allOrdersList");
			
			table.innerHTML = "";
			
			var tabHtml = '';
			
			tabHtml = tabHtml + '<table><tr><td>Sr No.</td>';
			tabHtml = tabHtml + '<td>Order ID</td>';
			tabHtml = tabHtml + '<td>Order Status</td>';
			tabHtml = tabHtml + '<td>Order Amount</td></tr>';
			
			localStorage.setItem('firstOrder', JSON.stringify({'srNo': _message[0].srNo, 'userId': _message[0].userId}));
			localStorage.setItem('lastOrder', JSON.stringify({'srNo': _message[_message.length - 1].srNo, 'userId': _message[0].userId}));
			
			for(var i = 0; i < _message.length; i++){
				
				tabHtml = tabHtml + '<tr><td>' + _message[i].srNo + '</td><td>';
				tabHtml = tabHtml + _message[i].orderId + '</td><td>';
				tabHtml = tabHtml + _message[i].orderStatus + '</td><td>';
				tabHtml = tabHtml + _message[i].orderAmount + '</td></tr>';
				
				//tabHtml = tabHtml + '</br><h2>Order Products</h2></br>';
				
				tabHtml = tabHtml + '<tr><td>Product ID</td>';
				tabHtml = tabHtml + '<td>Product Price</td>';
				tabHtml = tabHtml + '<td>Quantity</td></tr>';
				
				for(var j = 0; j < _message[i].useOrderProducts.length; j++){
					tabHtml = tabHtml + '<tr><td>' + _message[i].useOrderProducts[j].productId + '</td><td>';
					tabHtml = tabHtml + _message[i].useOrderProducts[j].productPrice + '</td><td>';
					tabHtml = tabHtml + _message[i].useOrderProducts[j].quantity + '</td></tr>';
				}
				
				//table.innerHTML = tabHtml + '</table>';
				
			}
			
			table.innerHTML = tabHtml + '</table>';
			
			allOrdersPage();
			
			break;
		}
	}

}

function populatePendingOrdersData(message){

	switch(message){
		case 'empty':{
			alert('I am sorry, No data found.');
			break;
		}
		case 'failure':{
			alert('I am sorry, your request could not be processed.');
			loginSuccessful();
			break;
		}
		default :{
			
			var _message = JSON.parse(message);
			
			var table = document.getElementById("pendingOrdersList");
			
			table.innerHTML = "";
			
			var tabHtml = '';
			
			tabHtml = tabHtml + '<table><tr><td>Sr No.</td>';
			tabHtml = tabHtml + '<td>Order ID</td>';
			tabHtml = tabHtml + '<td>Order Status</td>';
			tabHtml = tabHtml + '<td>Order Amount</td></tr>';
			
			for(var i = 0; i < _message.length; i++){
				
				tabHtml = tabHtml + '<tr><td>' + _message[i].srNo + '</td><td>';
				tabHtml = tabHtml + _message[i].orderId + '</td><td>';
				tabHtml = tabHtml + _message[i].orderStatus + '</td><td>';
				tabHtml = tabHtml + _message[i].orderAmount + '</td></tr>';
				
				//tabHtml = tabHtml + '</br><h2>Order Products</h2></br>';
				
				tabHtml = tabHtml + '<tr><td>Product ID</td>';
				tabHtml = tabHtml + '<td>Product Price</td>';
				tabHtml = tabHtml + '<td>Quantity</td></tr>';
				
				for(var j = 0; j < _message[i].useOrderProducts.length; j++){
					tabHtml = tabHtml + '<tr><td>' + _message[i].useOrderProducts[j].productId + '</td><td>';
					tabHtml = tabHtml + _message[i].useOrderProducts[j].productPrice + '</td><td>';
					tabHtml = tabHtml + _message[i].useOrderProducts[j].quantity + '</td></tr>';
				}
				
				//table.innerHTML = tabHtml + '</table>';
				
			}
			
			table.innerHTML = tabHtml + '</table>';
			
			pendingOrdersPage();
			
			break;
		}
	}

}
