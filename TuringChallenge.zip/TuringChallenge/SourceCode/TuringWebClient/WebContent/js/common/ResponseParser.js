function parseMessage(responseMessage){
	
	logConsoleMessage(responseMessage);
	
	var serviceId = responseMessage.split('-')[0];
	var message = responseMessage.split('-')[1];
	
	switch(serviceId){
		case 'validateUser':{
			switch(message){
				case 'USR_01':{
					alert('I am sorry, the information you provided is invalid.');
					break;
				}
				case 'failure':{
					alert('I am sorry, your request could not be processed.');
					break;
				}
				default :{
					localStorage.setItem('userInfo', message);
					loginSuccessful();
					break;
				}
			}
			break;
		}
		case 'addUser':{
			switch(message){
				case 'success':{
					alert('Thank you, your user has been added.');
					loginSuccessful();
					break;
				}
				case 'USR_01':{
					alert('I am sorry, invalid user id, passowrd or email is entered. user id/password length should be minimum 6 characters.');
					break;
				}
				case 'USR_04':{
					alert('I am sorry, the user id you have provided already exists.');
					break;
				}
				default :{
					alert('I am sorry, your request could not be processed.');
					break;
				}
			}
			break;
		}
		case 'updateUser':{
			switch(message){
				case 'success':{
					alert('Thank you, your profile information has been updated.');
					loginSuccessful();
					break;
				}
				case 'USR_01':{
					alert('I am sorry, invalid user id, passowrd or email is entered. user id/password length should be minimum 6 characters.');
					break;
				}
				default :{
					alert('I am sorry, your request could not be processed.');
					break;
				}
			}
			break;
		}
		case 'addUserOrder':{
			switch(message){
				case 'success':{
					alert('Thank you, your order has been added.');
					clearBucket();
					break;
				}
				default :{
					alert('I am sorry, your request could not be processed.');
					break;
				}
			}
			break;
		}
		case 'getNextNProducts':{
			populateProductsData(message);
			break;
		}
		case 'getPrevNProducts':{
			populateProductsData(message);
			break;
		}
		case 'getNextNOrders':{
			populateAllOrdersData(message);
			break;
		}
		case 'getPrevNOrders':{
			populateAllOrdersData(message);
			break;
		}
		case 'getUserOrdersByStatus':{
			populatePendingOrdersData(message);
			break;
		}
		default :{
			logConsoleMessage('Message type not found. serviceId(' +serviceId + ')');
			break;
		}
	}
	
}
