function validateUser(message){
	sendMessage('validateUser-' + message);		
}

function addUser(message){
	sendMessage('addUser-' + message);		
}

function updateUser(message){
	sendMessage('updateUser-' + message);		
}

function getNextNProducts(message){
	sendMessage('getNextNProducts-' + message);		
}

function getPrevNProducts(message){
	sendMessage('getPrevNProducts-' + message);		
}

function addUserOrder(message){
	sendMessage('addUserOrder-' + message);		
}

function getNextNOrders(message){
	sendMessage('getNextNOrders-' + message);		
}

function getPrevNOrders(message){
	sendMessage('getPrevNOrders-' + message);		
}

function getUserOrdersByStatus(message){
	sendMessage('getUserOrdersByStatus-' + message);		
}
