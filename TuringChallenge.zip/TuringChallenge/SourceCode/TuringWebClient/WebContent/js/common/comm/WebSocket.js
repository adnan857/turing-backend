var webSocket;

function openSocket(){

    webSocket = new WebSocket("ws://localhost:23130/TuringWebClient/websockethandler");

    webSocket.onopen = function(event){
        if(event.data === undefined){
        	return;
        }
        logConsoleMessage(event.data);
    };

    webSocket.onmessage = function(event){
    	parseMessage(event.data);
    };

    webSocket.onclose = function(event){
    	logConsoleMessage("Connection closed.");
    };
    
}

function sendMessage(message){
	
	if(webSocket !== undefined && webSocket.readyState !== WebSocket.CLOSED){
		webSocket.send(message);
    }else{
    	openSocket();
    }
	
}
