package com.turing.challenge.webclient;

import javax.websocket.EndpointConfig;
import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.turing.challenge.backend.cache.PropertiesLoaderThread;
import com.turing.challenge.backend.cache.PropertiesManager;
import com.turing.challenge.backend.service.ServiceExecutor;

@ServerEndpoint("/websockethandler")
public class WebSocketHandler {

	private static final Logger LOGGER = LogManager.getLogger(WebSocketHandler.class);
	
	static {
		LOGGER.info("properties.properties should be place here. systemPath(" + System.getProperty("user.dir") + ")");
		PropertiesManager.getInstance().loadProperties("properties.properties");
		PropertiesLoaderThread.getInstance();
	}
	
	@OnOpen
    public void onOpen(Session session, EndpointConfig config){
    	
		LOGGER.debug("session opened.");

		try {
			//session.getBasicRemote().sendText("connected...");
		}catch(Exception e) {
			
		}
		
    }
    
    @OnMessage
    public void onMessage(String message, Session session){

		LOGGER.debug("message(" + message + ")");

		try {
			String[] messageArray = message.split("-");
			session.getBasicRemote().sendText(messageArray[0] + "-" + ServiceExecutor.execute(messageArray[0], messageArray[1]));
		}catch(Exception e) {
			
		}
		
    }
 
    @OnClose
    public void onClose(Session session){
    	
    }
    
    @OnError
    public void onError(Session session, Throwable t){
    	
    }

}
